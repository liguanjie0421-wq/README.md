# 理財目標導航

以理財目標為核心的 PV / FV / PMT 試算網站。純靜態單一頁面，不需建置步驟。

## 部署到 Cloudflare Pages（拖放上傳）
1. 登入 Cloudflare Dashboard → Workers & Pages → Create → Pages → Upload assets（直接上傳）
2. 輸入專案名稱（例如 `goal-planner`）→ Create project
3. 把這個 zip 檔（或解壓後的資料夾）拖進上傳區 → Deploy site
4. 完成後會得到 `https://<專案名稱>.pages.dev` 網址；可在 Custom domains 綁定子網域（例如 `goal.hantutor.com`）

## 用 Wrangler 指令部署（選用）
```
npx wrangler pages deploy . --project-name goal-planner
```

## 檔案說明
- `index.html`：整個網站（HTML、CSS、JavaScript 都在這個檔案）
- `_headers`：Cloudflare Pages 的安全與快取標頭設定
- 字型由 Google Fonts 載入；使用者的目標資料存在各自瀏覽器的 localStorage，不會上傳到伺服器
