# 購屋房貸試算

純靜態網頁（單一 `public/index.html`，無依賴、無建置步驟）。所有計算都在瀏覽器內完成，不會上傳任何資料。

## 功能
- 房貸金額 = 房價 × 成數，自動計算
- 月繳／季繳／年繳，攤還表期數隨年限與頻率自動調整
- 自動核對：最後一期餘額、本金加總、付款加總
- 可行性判斷：自備款缺口、月付金占收入比、每月現金流、房價上限
- 利率 × 年限壓力表

## 上傳到 GitHub
1. 在 GitHub 建立新的空 repository（不要勾選 README / .gitignore）。
2. 在本資料夾執行：
   ```bash
   git init
   git add .
   git commit -m "init"
   git branch -M main
   git remote add origin https://github.com/<你的帳號>/house-calculator.git
   git push -u origin main
   ```
   或直接在 GitHub 網頁選 "uploading an existing file"，把整個資料夾內容拖進去。

## 部署到 Cloudflare（二選一）

### 方式 A：Pages 連接 GitHub（最簡單）
1. Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git，選此 repo。
2. Framework preset：None；Build command：留空；Build output directory：`public`。
3. Save and Deploy。之後每次 push 到 main 都會自動更新。

### 方式 B：Workers（使用 wrangler.jsonc）
1. Workers & Pages → Create → Import a repository，選此 repo。
2. Build command 留空；Deploy command 使用預設 `npx wrangler deploy`。
3. 或在本機執行 `npx wrangler deploy`（需先 `npx wrangler login`）。

## 本機預覽
```bash
npx wrangler dev
# 或直接用瀏覽器開啟 public/index.html
```

## 專案結構
```
house-calculator/
├─ public/
│  ├─ index.html     # 網頁本體
│  └─ _headers       # 安全標頭
├─ wrangler.jsonc    # Cloudflare 設定
├─ package.json
├─ .gitignore
└─ README.md
```
