購屋房貸試算（純靜態網頁，無需建置）
Cloudflare Pages：Workers & Pages → Create → Pages → Upload assets → 上傳此 ZIP（index.html 位於根目錄）。
